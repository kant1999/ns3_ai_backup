import torch
pthfile = '/home/zhr/workspace/ns-allinone-3.37/ns-3.37/scratch/CW7/checkpoints/DQN/Q_eval_1/DQN_q_eval_0.pth'

net = torch.load(pthfile)
print(net)