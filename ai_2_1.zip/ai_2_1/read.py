filename='/home/zhr/workspace/ns-allinone-3.37/ns-3.37/scenario2_cw3.log'
a=[]
b=0
start=101
end=164

i=0
for line in open(filename,"r"):
    line=line.split()
    a=float(line[-1])
    i=i+1
    if i>start-1 and i<end+1:
     b=b+a
     #print(line)
     #print(a)
print(b/(end-start+1))